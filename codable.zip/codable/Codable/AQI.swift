

import Foundation



struct AQI: Codable {
    let records : [Records]    //依照postman該json字串格式
    
    struct Records: Codable{
        var County: String
        var SiteName: String
        var AQI: String
        var Status: String
        var PublishTime: String
    }

}
