

import UIKit
import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

class ViewController: UIViewController {
        
    
        var aqiCount = 0
        var county:[String] = []
        var siteName:[String] = []
        var aqiValue:[String] = []
        var aqiStatus:[String] = []
        var aqiTime:[String] = []
        
    
    @IBOutlet var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        
        var request = URLRequest(url: URL(string: "https://data.epa.gov.tw/api/v1/aqx_p_432?limit=1000&api_key=9be7b239-557b-4c10-9775-78cadfc555e9&format=json")!,timeoutInterval: Double.infinity)
    
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            let decoder = JSONDecoder()
            if let data = data, let aa = try? decoder.decode(AQI.self, from: data){
                            
                self.aqiCount = aa.records.count
                for aqi in aa.records {
//                        print(aqi)
                        self.county.append(aqi.County)
                        self.siteName.append(aqi.SiteName)
                        self.aqiValue.append(aqi.AQI)
                        self.aqiStatus.append(aqi.Status)
                        self.aqiTime.append(aqi.PublishTime)
                    }

                }
                else {
                    print("error")
                }
            DispatchQueue.main.sync {
                self.tableView.reloadData()
            }
            
        }
        task.resume()
    }
}





//表格三階段
extension ViewController: UITableViewDataSource,UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aqiCount
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = county[indexPath.row] + " " + siteName[indexPath.row] + " " + aqiValue[indexPath.row] + " " + aqiStatus[indexPath.row] + " " + aqiTime[indexPath.row]
//        cell.detailTextLabel?.text = aqiStatus[indexPath.row] + " " + aqiTime[indexPath.row]
        
        return cell
    }
    
}
